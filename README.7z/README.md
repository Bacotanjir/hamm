<h1 align="center">
  Ngen
</h1>
</div>
<p align="center">
  Made with ❤️ by <a href="https://www.facebook.com/
Hammstor">Hammstor_</a>
</p>
<p align="center">
 
### menu
 <img src="https://github.com/Hamm/hammgans/blob/main/.ppk/carbon.png" width="640" title="Menu" alt="Menu">
</p>

#### Results
 <img src="https://github.com/Bacotanjir/Hammgans/blob/main/.ppk/hamm.jpg" width="640" title="Menu" alt="Menu">
</p>

###### notice me: if you get cp results, save 3/7 days then log in.

<a href="https://github.com/Bacotanjir/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Bacotanjir?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/Bacotanjir/termux-style/stargazers/">
  <a href="https://github.com/Bacotanjir/Hammgans">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/Bacotanjir/Hammgans.svg"/>
  </a>
  <a href="https://github.com/Bacotanjir/Hammgans">
    <img alt="Language" src="https://img.shields.io/github/languages/count/Bacotanjir/Hammgans.svg"/>
  </a>
  <a href="https://github.com/Bacotanjir/Hammgans">
    <img alt="Search" src="https://img.shields.io/github/search/Bacotanjir/Hammgans/.svg"/>
  </a>
  <a href="https://github.com/Bacotanjir/Hammgans">
    <img alt="Starts" src="https://img.shields.io/github/stars/Bacotanjir/Hammgans.svg"/>
  </a>
<a href="https://github.com/Bacotanjir/Hammgans">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/Bacotanjir/Hammgans.svg"/>
  </a>

<a href="https://github.com/Bacotanjir/Hammgans">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/Bacotanjir/Hammgans.svg"/> <a href="https://github.com/Bacotanjir/Hammgans">
    <img alt="Forks" src="https://img.shields.io/github/forks/Bacotanjir/Hammgans.svg"/>
  </a>
</div>
<p align="center">

#### Install script on Termux
```bash
$ pkg update && pkg upgrade
$ pkg install python2
$ pkg install git
$ git clone https://github.com/Bacotanjir/Hammgans
$ pip2 install requests bs4
$ pip2 install futures
```
#### Run script
```bash
$ cd Hammgans
$ python2 Hammgans.py
```
#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Bacotanjir) [![](https://img.shields.io/badge/Twitter-blue?logo=Twitter&logoColor=White&labelColor=white)](https://mobile.twitter.com/moch_xd)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/Hammstor)[![](https:.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https://www.instagram.com/_Hammgans13_/) [![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6282370472429?text=Asalamualaikum+bang)

##### catatan:
gunakanlah dengan bijak, atas apapun yang terjadi admin tidak bertanggung jawab.


##### Notice Me : Please Don't Change Name Author Thanks For Using My Script
